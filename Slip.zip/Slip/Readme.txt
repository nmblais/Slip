The game of Slip (JackalChess)

Rules' summary.

Slip is a game for two players. 
Each player has seven pawns and one queen positioned, at the start of the game,
on a board placed in between the two. The board has 24 squares (6 rows of 4 squares). 
The goal of the game is to be the first to reach the last row with a pawn.

There are 8 different starting positions characterized by the placement of the queens 
and who has the first move.

"+---+---+---+---+"
"| p | q | p | p |"
"+---+---+---+---+"
"| p | p | p | p |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"| P | P | P | P |"
"+---+---+---+---+"
"| P | P | Q | P |"
"+---+---+---+---+"

"+---+---+---+---+"
"| p | q | p | p |"
"+---+---+---+---+"
"| p | p | p | p |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"| P | P | P | P |"
"+---+---+---+---+"
"| P | Q | P | P |"
"+---+---+---+---+"

"+---+---+---+---+"
"| p | p | q | p |"
"+---+---+---+---+"
"| p | p | p | p |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"| P | P | P | P |"
"+---+---+---+---+"
"| P | Q | P | P |"
"+---+---+---+---+"

"+---+---+---+---+"
"| p | p | q | p |"
"+---+---+---+---+"
"| p | p | p | p |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"|   |   |   |   |"
"+---+---+---+---+"
"| P | P | P | P |"
"+---+---+---+---+"
"| P | P | Q | P |"
"+---+---+---+---+"

For convenience, the board and the squares are labelled:

"  +---+---+---+---+"
"6 |a6 |b6 |c6 |d6 |"
"  +---+---+---+---+"
"5 |a5 |b5 |c5 |d5 |"
"  +---+---+---+---+"
"4 |a4 |b4 |c4 |d4 |"
"  +---+---+---+---+"
"3 |a3 |b3 |c3 |d3 |"
"  +---+---+---+---+"
"2 |a2 |b2 |c2 |d2 |"
"  +---+---+---+---+"
"1 |a1 |b1 |c1 |d1 |"
"  +---+---+---+---+"
"    A   B   C   D  "

The top of the board is called the North and the bottom, the South. 
Either side, the South or the North is allowed to play the first move 
depending on the starting position.

The players play one move a time in alternate fashion. A move consists 
in taking a piece from a square and moving it to another square. 
The destination square must either be empty or occupied by a piece from 
the other camp. In the latter case, the move is called a capture and the 
piece from the other camp is removed from the board. A special capture, 
called "en-passant" will be explained later.

The pieces borrowed their movement from the game of Chess. In that sense, 
Slip (or JackalChess) maybe called a Chess-Variant.

The pawn, like in Chess, moves in one direction, on its column, one square at a time. 
The pawns located on the first row are allowed to move one or two squares the first 
time they move. A pawn captures in diagonal on a square situated one row in front of it 
and on the adjacent column. For instance, a south pawn on b2 can capture any north pieces 
situated on a3 or c3. Similarly, a north pawn on b5 controls the a4 and c4 squares. 
If a pawn moves two squares and, by doing so, passes over a square controlled by an 
enemy pawn, the pawn can be captured by the enemy pawn like if the first pawn had moved 
only one square. This type of capture is called "en-passant" and is only allowed 
immediately after the pawn has moved two squares.

The queen, like in Chess, moves in any directions, any number of uninterrupted sequence 
of empty squares. The queen moves in one direction at a time (diagonally, horizontally, 
or vertically). The queen cannot move beyond a square occupied by another piece. 
If the other piece is from the other camp, the queen can capture it.

Once a pawn has reached the last row, it cannot be captured and the game is over.

There are six ways to end a game of Slip and each of them has a score assigned to it:

1 - A player earns three points if one of his pawn reach the last row. 
2- If, a player, having to move a piece, has no legal move left, the game is over 
and the other player scores one point. 
3- If there are no more pawns on the board, only the queens, the game is a draw if 
the queens don't attack each other; in that case, the game is over and the players 
score zero point. 
4- If, both players play a combined total of 10 moves without a pawn move or a capture, 
the game is automatically a draw (score zero point.)
5- If one player resigns, the other player scores three points. 
6- Both players can agree to stop the game at any time; in that case, 
the game is a draw and nobody wins any point.

A match between two players is a set of eight games in a row where each game starts 
with one of the eight different starting positions (mentioned above.) The total of 
points scored after each game determines the winner of the match.


Normand M. Blais

blais_normand <msn_com>

Jan 2 2017











